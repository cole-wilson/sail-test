# Test Project



## Installation
### With pip:
`pip3 install sail_test`
### Mac and Windows and Unix
Get the executable from the [latest release](/releases/latest).

## Usage:
Run `sail_test` in your terminal or run the application file.
## Contributors
 - Cole Wilson
## Contact
<>